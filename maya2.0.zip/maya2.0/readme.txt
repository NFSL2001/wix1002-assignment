WIX1002 2021/2022 Semester 1
Occ 8 Group 3

Group members:
EZYAN MUNIRAH BINTI ZAINUDDIN (U2000643)
NURAUFA NATASHA BINTI AZROL (U2102739)
AINA SOFEA BINTI AZHAR (U2102790)
PENDAR TABATABAEEMOSHIRI (S2029817)
KOO SONG LE (S2116593)

The main class to run is in main.java. Run `updatemaya` in Apache NetBeans 12.6.

If the background image is not showing, please check `\com.um.maya\src\main\java\com\um\maya\Login_Signup.java` line 344:

```
jLabel11.setIcon(new javax.swing.ImageIcon(Globals.path+"\\src\\main\\java\\com\\um\\maya\\bg.jpg")); // NOI18N
```

Replace (Globals.path+"\\src\\main\\java\\com\\um\\maya\\bg.jpg") with your directory path (e.g. ("E:\\UM_Java\\wix1002-assignment\\maya\\com.um.maya\\src\\main\\java\\com\\um\\maya\\bg.jpg"))
